#!/usr/bin/env python3
"""Offline release builder. Default is read-only; --apply writes local artifacts only."""
from pathlib import Path
import argparse,base64,hashlib,io,json,re,zipfile
ROOT=Path(__file__).resolve().parent.parent
SOURCE=ROOT/'AI对话导出插件_原格式排版版'
PUBLIC=ROOT/'上传部署-只拖这个文件夹'
FILES=['manifest.json','popup.html','popup.js','doubao-adapter.js','chatgpt-adapter.js','export-integrity.js','text-export.js','gemini-adapter.js','rich-export.js','icon16.png','icon48.png','icon128.png','release-config.json','vendor/marked.umd.js','vendor/marked.LICENSE.md','使用说明.md','PRIVACY.md','LICENSE']
def digest(b):return hashlib.sha256(b).hexdigest()
def plan():
    actual={str(p.relative_to(SOURCE)) for p in SOURCE.rglob('*') if p.is_file() and p.name!='.DS_Store'}
    assert actual==set(FILES),'源码文件不符合白名单；停止打包'
    manifest=json.loads((SOURCE/'manifest.json').read_text())
    version=manifest['version'];assert re.fullmatch(r'\d+\.\d+\.\d+',version)
    config=json.loads((SOURCE/'release-config.json').read_text());assert config['currentVersion']==version
    release_date=config['releaseDate'];assert re.fullmatch(r'\d{4}-\d{2}-\d{2}',release_date)
    assert manifest['permissions']==['activeTab','scripting'] and manifest['host_permissions']==['https://chat.baochaolab.com/*'],'权限变化需独立核验'
    mem=io.BytesIO()
    with zipfile.ZipFile(mem,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for rel in FILES:
            data=(SOURCE/rel).read_bytes()
            if rel.endswith(('.js','.json','.md','.html')):
                text=data.decode('utf-8');assert not re.search(r'/Users/|/home/|sk-[A-Za-z0-9]{20,}|AKID[A-Za-z0-9]{20,}',text),'公开文件包含私有路径或疑似凭证'
            info=zipfile.ZipInfo(SOURCE.name+'/'+rel,(2026,10,26,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,data)
    data=mem.getvalue();name=f'AI对话导出插件_v{version}.zip'
    release=json.loads((PUBLIC/'release.json').read_text())
    release.update(version=version,latestVersion=version,lastUpdated=release_date,updatedAt=release_date,downloadFile=name,sha256=digest(data),notes=config['notes'])
    html=(PUBLIC/'index.html').read_text()
    html=re.sub(r'<script id="release-data" type="application/json">.*?</script>',lambda m:'<script id="release-data" type="application/json">'+json.dumps(release,ensure_ascii=False,separators=(',',':'))+'</script>',html,count=1,flags=re.S)
    html=re.sub(r'AI对话导出插件_v\d+\.\d+\.\d+\.zip',name,html)
    html=re.sub(r'v\d+\.\d+\.\d+(?= - 安装| · 上次更新)',f'v{version}',html)
    html=re.sub(r'上次更新：\d{4}-\d{2}-\d{2}','上次更新：'+release_date,html)
    html=re.sub(r'const PLUGIN_B64="[A-Za-z0-9+/=]+";',lambda m:'const PLUGIN_B64="'+base64.b64encode(data).decode()+'";',html,count=1)
    result={name:data,'index.html':html.encode(),'release.json':(json.dumps(release,ensure_ascii=False,indent=2)+'\n').encode()}
    for f in PUBLIC.rglob('*'):
        if f.is_file() and f.name!='.DS_Store' and f.suffix!='.zip' and str(f.relative_to(PUBLIC)) not in result:result[str(f.relative_to(PUBLIC))]=f.read_bytes()
    assert len(result)==6,'部署文件数量异常'
    return result
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--apply',action='store_true');ap.add_argument('--check',action='store_true');args=ap.parse_args();result=plan()
    if args.check:
        expected={k:digest(v) for k,v in result.items()}
        assert json.loads((ROOT/'文件校验.json').read_text())==expected,'源码与已构建发布物不一致'
        for k,v in result.items():assert (PUBLIC/k).read_bytes()==v,'发布物未同步：'+k
        print('源码、独立ZIP、内嵌ZIP、版本与6项部署文件一致；0 API、0上传。')
    elif args.apply:
        for k,v in result.items():(PUBLIC/k).write_bytes(v)
        for f in PUBLIC.glob('AI对话导出插件_v*.zip'):
            if f.name not in result:f.unlink()
        (ROOT/'文件校验.json').write_text(json.dumps({k:digest(v) for k,v in result.items()},ensure_ascii=False,indent=2)+'\n')
        print('已更新本地发布物；未上传。')
    else:
        print(json.dumps({'mode':'dry-run','version':json.loads((SOURCE/'manifest.json').read_text())['version'],'files':{k:len(v) for k,v in result.items()},'apiCalls':0,'uploads':0},ensure_ascii=False,indent=2))
