from pathlib import Path
import json,hashlib
r=Path(__file__).resolve().parent.parent
p=r/'上传部署-只拖这个文件夹'
m=json.loads((r/'文件校验.json').read_text())
a={str(f.relative_to(p)) for f in p.rglob('*') if f.is_file() and f.name!='.DS_Store'}
assert a==set(m),'文件增减，请核实版本并更新文件校验.json'
for n,h in m.items(): assert hashlib.sha256((p/n).read_bytes()).hexdigest()==h,'文件已变化，请核实版本：'+n
assert (p/'index.html').is_file()
print(f'发布物一致性检查通过：{len(m)} 个部署文件；不代表功能验收完成。')

import subprocess,sys
subprocess.run([sys.executable,str(r/"scripts/build_release.py"),"--check"],check=True)

import shutil
node=shutil.which("node")
assert node,"缺少 Node.js，离线核心功能预检未运行；停止预检。"
subprocess.run([node,str(r/"scripts/functional_preflight.cjs")],check=True)
