#!/usr/bin/env node
'use strict';
// Offline core invariants only. No network, paid APIs, downloads or product writes.
const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('node:assert/strict');
const source=path.resolve(__dirname,'../AI对话导出插件_原格式排版版');
const context=vm.createContext({URL,location:{href:'https://chatgpt.com/c/fixture',origin:'https://chatgpt.com',pathname:'/c/fixture'},document:{querySelectorAll:()=>[]},setTimeout,clearTimeout,setInterval,clearInterval});
for(const file of ['export-integrity.js','chatgpt-adapter.js','text-export.js','gemini-adapter.js'])vm.runInContext(fs.readFileSync(path.join(source,file),'utf8'),context,{filename:file});
let checks=0;function check(name,fn){fn();checks++;console.log('通过：'+name);}
const I=context.AIExportIntegrity,G=context.AIExportChatGPT;
const rows=[{role:'用户',content:'继续'},{role:'ChatGPT',content:'同一个开头'.repeat(12)+'甲'},{role:'ChatGPT',content:'同一个开头'.repeat(12)+'乙'},{role:'用户',content:'引用\n\n【ChatGPT说】\n<box><text>示例标签</text></box>'}];
check('短消息、相同前缀与字面角色标记不改变消息数量',()=>{let t=I.typed(rows,'验收');assert.equal(t.turns.length,4);rows.forEach((x,i)=>assert.equal(t.turns[i].content,x.content));});
check('真实 XML 代码不因标签名称被改写',()=>assert.equal(G.message({author:{role:'assistant'},content:{parts:['<box><text>示例标签</text></box>']}}),'<box><text>示例标签</text></box>'));
check('当前分支不冒充全部重新生成分支',()=>{let m={root:{parent:null},a:{parent:'root',message:{author:{role:'user'},content:{parts:['继续']}}},b:{parent:'a',message:{author:{role:'assistant'},content:{parts:['好']}}},other:{parent:'a',message:{author:{role:'assistant'},content:{parts:['另一分支']}}}};let a=G.currentMessages({mapping:m,current_node:'b'});assert.equal(a.length,2);assert.equal(a[1].content.parts[0],'好');assert.throws(()=>G.currentMessages({mapping:m}),/缺少当前分支/);});
check('断裂节点链停止导出',()=>assert.throws(()=>G.currentMessages({mapping:{a:{parent:'missing'}},current_node:'a'}),/节点链不完整/));
check('媒体没有文字也保留明确提示',()=>assert.match(G.rawMessage({content:{parts:[{content_type:'image_asset_pointer'}]}}),/图片/));
check('同标题不同会话文件名不同且不过长',()=>{let a=I.filename('长'.repeat(100),'html','/c/abc'),b=I.filename('长'.repeat(100),'html','/c/def');assert.notEqual(a,b);assert.ok(Buffer.byteLength(a)<255);});
check('Claude 身份不符不能导出',()=>assert.throws(()=>I.claude({uuid:'other',chat_messages:[]},'target'),/身份与目标不符/));
check('扩展入口保留完整性模块，持续主机权限仅限更新站点',()=>{let p=fs.readFileSync(path.join(source,'popup.js'),'utf8'),m=JSON.parse(fs.readFileSync(path.join(source,'manifest.json')));assert.ok(p.includes("'export-integrity.js'"));assert.deepEqual(m.permissions,['activeTab','scripting']);assert.deepEqual(m.host_permissions,['https://chat.baochaolab.com/*']);assert.ok(!m.background&&!m.content_scripts);});
check('TXT模块空输入不冒充成功、取消与错误会话保持保护',()=>{let T=context.AIExportText;assert.equal(T.capture(()=>[],{target:'/c/fixture'}),null);assert.throws(()=>T.capture(()=>[],{cancelled:()=>true}),/已停止/);assert.throws(()=>T.capture(()=>[],{target:'/c/other'}),/地址改变/);});
check('HTML组件字面量表格保留中文字段、零值和顺序',()=>{let s=G.htmlSourceFallback('<box gap={2}>{#each [{项目:"甲",数量:0},{项目:"乙",数量:12}] as x}<text>{x.项目}</text>{/each}</box>');assert.ok(s.includes('| 甲 | 0 |'));assert.ok(s.includes('| 乙 | 12 |'));assert.ok(!s.includes('{#each'));});
check('HTML组件解释不执行动态表达式，代码块原样保留',()=>{let code='```jsx\n<box gap={2}>示例</box>\n```';assert.equal(G.htmlSourceFallback(code),code);assert.equal(G.htmlNeedsView(code),false);assert.ok(!G.htmlSourceFallback('<box gap={2}>{arbitraryFunction()}</box>').includes('arbitraryFunction()'));});
check('Gemini历史缺终页与错误会话拒绝直接导出',()=>{const G=context.AIExportGemini;assert.throws(()=>G.parsePage([[]],'c_test'),/分页边界/);assert.throws(()=>G.parsePage([[[['c_other','r_1']]],null],'c_test'),/身份/);});
check('Gemini历史只接受明确分页和完成回复',()=>{let t=[['c_test','r_1'],null,[['提问']],[[['rc_1',['回答'],null,null,null,null,null,null,[2]]]]];let r=context.AIExportGemini.parsePage([[t],null],'c_test');assert.equal(r.ids[0],'1');assert.equal(r.cursor,null);assert.throws(()=>context.AIExportGemini.parsePage([[],'next'],'c_test'),/空页/);});
console.log(`离线核心预检：${checks} 项通过；0 API、0 上传、0 成品改写。此检查不代表真实网站或浏览器安装验收完成。`);
